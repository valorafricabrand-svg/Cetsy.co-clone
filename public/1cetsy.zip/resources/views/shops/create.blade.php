{{-- resources/views/shops/create.blade.php --}}
@extends('layouts.app')

@section('content')
<div class="container mx-auto max-w-3xl py-8">
    <h2 class="text-3xl font-bold mb-6 text-center">Create Your Shop</h2>

    {{-- Flash Success --}}
    @if(session('success'))
      <div class="mb-6 p-4 bg-green-100 text-green-800 rounded">
        {{ session('success') }}
      </div>
    @endif

    {{-- Validation Errors --}}
    @if($errors->any())
      <div class="mb-6 p-4 bg-red-100 text-red-800 rounded">
        <ul class="list-disc pl-5 space-y-1 mb-0">
          @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
          @endforeach
        </ul>
      </div>
    @endif

    <form 
      action="{{ route('shops.store') }}" 
      method="POST" 
      enctype="multipart/form-data"
      x-data="{ name: '{{ old('name') }}', slug: '{{ old('slug') }}' }"
      @input.debounce.300ms="
        slug = name.toLowerCase()
                   .trim()
                   .replace(/[^a-z0-9]+/g,'-')
                   .replace(/(^-|-$)/g,'');
      "
      class="space-y-8"
    >
      @csrf

      {{-- 1) Shop Preferences --}}
      <section class="bg-white shadow rounded-lg p-6">
        <h3 class="text-xl font-semibold mb-4">1. Shop Preferences</h3>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label for="language" class="block font-medium mb-1">
              Language <span class="text-red-500">*</span>
            </label>
            <select name="language" id="language" required
                    class="w-full border-gray-300 rounded px-3 py-2">
              <option value="" disabled>Select language</option>
              <option {{ old('language')=='English'?'selected':'' }}>English</option>
              <option {{ old('language')=='Spanish'?'selected':'' }}>Spanish</option>
              <option {{ old('language')=='French'?'selected':'' }}>French</option>
            </select>
          </div>
          <div>
            <label for="country" class="block font-medium mb-1">
              Country <span class="text-red-500">*</span>
            </label>
            <select name="country" id="country" required
                    class="w-full border-gray-300 rounded px-3 py-2">
              <option value="" disabled>Select country</option>
              <option {{ old('country')=='United States'?'selected':'' }}>United States</option>
              <option {{ old('country')=='Canada'?'selected':'' }}>Canada</option>
              <option {{ old('country')=='United Kingdom'?'selected':'' }}>United Kingdom</option>
            </select>
          </div>
          <div>
            <label for="currency" class="block font-medium mb-1">
              Currency <span class="text-red-500">*</span>
            </label>
            <select name="currency" id="currency" required
                    class="w-full border-gray-300 rounded px-3 py-2">
              <option value="" disabled>Select currency</option>
              <option {{ old('currency')=='USD'?'selected':'' }}>USD</option>
              <option {{ old('currency')=='CAD'?'selected':'' }}>CAD</option>
              <option {{ old('currency')=='GBP'?'selected':'' }}>GBP</option>
            </select>
          </div>
        </div>
      </section>

      {{-- 2) Name & Slug --}}
      <section class="bg-white shadow rounded-lg p-6">
        <h3 class="text-xl font-semibold mb-4">2. Name Your Shop</h3>
        <div class="mb-4">
          <label for="name" class="block font-medium mb-1">
            Shop Name <span class="text-red-500">*</span>
          </label>
          <input 
            id="name" name="name" type="text"
            x-model="name"
            required
            class="w-full border-gray-300 rounded px-3 py-2"
            placeholder="e.g. MyCraftShop"
          >
        </div>
        <div>
          <label for="slug" class="block font-medium mb-1">
            Slug (URL Identifier)
          </label>
          <div class="flex items-center space-x-2">
            <span class="text-gray-500">{{ url('shop') }}/</span>
            <input 
              id="slug" name="slug" type="text"
              x-model="slug"
              readonly
              class="flex-1 bg-gray-100 border-gray-300 rounded px-3 py-2"
            >
          </div>
          <p class="text-sm text-gray-500 mt-1">
            Auto-generated from your shop name.
          </p>
        </div>
      </section>

      {{-- 3) How You’ll Get Paid --}}
      <section class="bg-white shadow rounded-lg p-6">
        <h3 class="text-xl font-semibold mb-4">3. How You’ll Get Paid</h3>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label for="bank_account" class="block font-medium mb-1">
              Bank Account # <span class="text-red-500">*</span>
            </label>
            <input 
              id="bank_account" name="bank_account" type="text"
              value="{{ old('bank_account') }}"
              required
              class="w-full border-gray-300 rounded px-3 py-2"
              placeholder="000123456789"
            >
          </div>
          <div>
            <label for="routing_number" class="block font-medium mb-1">
              Routing # <span class="text-red-500">*</span>
            </label>
            <input 
              id="routing_number" name="routing_number" type="text"
              value="{{ old('routing_number') }}"
              required
              class="w-full border-gray-300 rounded px-3 py-2"
              placeholder="011000015"
            >
          </div>
        </div>
      </section>

      {{-- 4) Share Your Billing Info --}}
      <section class="bg-white shadow rounded-lg p-6">
        <h3 class="text-xl font-semibold mb-4">4. Share Your Billing Info</h3>
        <div class="mb-4">
          <label for="address" class="block font-medium mb-1">
            Street Address <span class="text-red-500">*</span>
          </label>
          <input 
            id="address" name="address" type="text"
            value="{{ old('address') }}"
            required
            class="w-full border-gray-300 rounded px-3 py-2"
            placeholder="123 Main St"
          >
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label for="city" class="block font-medium mb-1">
              City <span class="text-red-500">*</span>
            </label>
            <input 
              id="city" name="city" type="text"
              value="{{ old('city') }}"
              required
              class="w-full border-gray-300 rounded px-3 py-2"
              placeholder="Anytown"
            >
          </div>
          <div>
            <label for="postal" class="block font-medium mb-1">
              Postal Code <span class="text-red-500">*</span>
            </label>
            <input 
              id="postal" name="postal" type="text"
              value="{{ old('postal') }}"
              required
              class="w-full border-gray-300 rounded px-3 py-2"
              placeholder="12345"
            >
          </div>
        </div>
      </section>

 

      {{-- Submit --}}
      <div class="text-right">
        <button 
          type="submit"
          class="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-2 rounded"
        >
          Finish & Create
        </button>
      </div>
    </form>
</div>
@endsection
